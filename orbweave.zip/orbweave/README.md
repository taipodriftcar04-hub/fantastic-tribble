# Orbweave: deploy to Vercel

Folder layout:

    index.html        the landing page
    api/invite.js     serverless function that emails you each invite request

## 1. Deploy
- Push this folder to a GitHub repo, then import it at vercel.com/new (no build settings needed).
- Or run `npx vercel` inside this folder.

## 2. Turn on analytics
- Vercel dashboard > your project > Analytics tab > Enable Web Analytics.
- Redeploy. Page views and referrers appear within minutes. It is cookieless.
- Custom events (`demo_send`, `invite_request`) need a Vercel Pro plan. On the free plan you still get visitors and page views.

## 3. Get invite requests by email
- Create a free account at resend.com and make an API key.
- In Vercel > Settings > Environment Variables add:
  - `RESEND_API_KEY` = your key
  - `INVITE_TO_EMAIL` = the inbox that should receive requests
- Redeploy. Until you verify your own domain in Resend, the test sender only delivers to the email you signed up to Resend with, so use that address for `INVITE_TO_EMAIL`.
- Later, verify a domain in Resend and set `INVITE_FROM_EMAIL` (for example `Orbweave <invites@yourdomain.com>`).

## 4. Turn on the picture wall
Folder layout now also includes `package.json` and `api/upload.js`, `api/wall.js`, `api/admin.js`.

- Vercel dashboard > Storage > Create > Blob. Connect it to this project (this adds `BLOB_READ_WRITE_TOKEN` automatically).
- Add an environment variable `ADMIN_KEY` with a long random string (at least 16 characters).
- Redeploy.
- Review uploads at `https://YOUR-SITE/api/admin?key=YOUR_ADMIN_KEY`. Approve a picture to put it on the wall, or delete it.
- Keep that address private. Anyone with the key can approve or delete pictures.

How it protects you and your visitors:
- Every picture is redrawn in the visitor's browser, which removes GPS and camera data before upload.
- The server accepts only real JPEG files up to 2 MB and limits each visitor to 5 uploads per 10 minutes.
- Nothing is public until you approve it. Do not skip this step: open anonymous uploads attract illegal and abusive images.
- In Vercel > Firewall, add a rate-limit rule for `/api/upload` for stronger protection against floods.
- If you ever find child sexual abuse material, do not view or keep it further. Delete it and report it to NCMEC (CyberTipline) in the US or the Internet Watch Foundation in the UK.

## 5. Invite codes and the members area
New files: `members.html`, `api/join.js`, `api/members.js`, `api/member-image.js`, `api/_auth.js`.

- Add one more environment variable in Vercel: `SESSION_SECRET` = a random string of 32+ characters. Redeploy.
- Open `https://YOUR-SITE/api/admin?key=YOUR_ADMIN_KEY`, choose how long the code should last, and press Create code.
- Email the code to the person who asked for an invite. They go to `/members.html`, enter it, and can post and view pictures.
- Sessions last 30 days. Codes stop working after their expiry date.
- To block one code early, add its first 6 letters to a `REVOKED_CODES` environment variable (comma-separated) and redeploy. Changing `SESSION_SECRET` signs out every member and invalidates every code.
- Member pictures appear instantly (no review step), so check the "Member pictures" section on the admin page regularly and delete anything that breaks your rules.

Be honest with members about what "private" means here: pictures are only shown to signed-in members, but they are stored on Vercel's storage and you (the owner) can see them. They are not end-to-end encrypted.

## 6. Post products every day
New files: `api/products.js`, `api/_products.js`. Nothing extra to set up beyond the Blob store and `ADMIN_KEY`.

- Open `https://YOUR-SITE/api/admin?key=YOUR_ADMIN_KEY` (bookmark it, and keep it private).
- In **Post a product**: choose a picture, type the name, price and a short description, add a buy link if you have one, and press Post.
- The product appears in a **New products** section at the top of the home page within about a minute, newest first. The section stays hidden until you post your first product.
- To remove a product, press Delete under it in **Posted products** on the same page.

## 7. Check it works
- Submit the form on the live site. The email should reach your inbox within seconds.
- If the page shows an error, open Vercel > Logs and look at `/api/invite`.
