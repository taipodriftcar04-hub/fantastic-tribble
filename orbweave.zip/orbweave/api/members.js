// Members only (needs the sign-in cookie from /api/join).
// GET  /api/members  -> { images: [ "/api/member-image?u=...", ... ] } newest first
// POST /api/members  (raw JPEG bytes) -> saves a private picture

const { put, list } = require("@vercel/blob");
const { readSession, readBody, limited } = require("./_auth");

const MAX_BYTES = 2 * 1024 * 1024;

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  const session = readSession(req);
  if (!session) return res.status(401).json({ error: "Sign in with an invite code." });

  if (req.method === "GET") {
    try {
      const { blobs } = await list({ prefix: "members/", limit: 200 });
      blobs.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
      return res.status(200).json({
        images: blobs.map((b) => "/api/member-image?u=" + encodeURIComponent(b.url)),
      });
    } catch (e) {
      return res.status(200).json({ images: [] });
    }
  }

  if (req.method === "POST") {
    if (limited("mem:" + session.id, 20, 10 * 60 * 1000)) {
      return res.status(429).json({ error: "Too many uploads" });
    }
    try {
      const buf = await readBody(req, MAX_BYTES);
      if (buf.length > MAX_BYTES) return res.status(413).json({ error: "Too large" });
      if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) {
        return res.status(400).json({ error: "Not a JPEG" });
      }
      await put("members/pic.jpg", buf, { access: "public", contentType: "image/jpeg", addRandomSuffix: true });
      return res.status(200).json({ ok: true });
    } catch (e) {
      if (e && e.code === 413) return res.status(413).json({ error: "Too large" });
      return res.status(500).json({ error: "Upload failed" });
    }
  }

  res.setHeader("Allow", "GET, POST");
  return res.status(405).json({ error: "Method not allowed" });
};
