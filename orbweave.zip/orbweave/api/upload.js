// POST /api/upload  (body: raw JPEG bytes, Content-Type: image/jpeg)
// Stores the picture in the private-review area ("pending/"). It is NOT shown on
// the wall until you approve it at /api/admin?key=YOUR_ADMIN_KEY.

const { put } = require("@vercel/blob");

const MAX_BYTES = 2 * 1024 * 1024; // 2 MB (the page already shrinks pictures to fit)

// Light per-instance limiter. For strong limits, also add a Vercel Firewall rate-limit rule on /api/upload.
const hits = new Map();
function limited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < 10 * 60 * 1000);
  recent.push(now);
  hits.set(ip, recent);
  return recent.length > 5; // 5 pictures per 10 minutes per visitor
}

async function readBody(req) {
  if (Buffer.isBuffer(req.body)) return req.body;
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BYTES) throw Object.assign(new Error("too large"), { code: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const ip = (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
  if (limited(ip)) return res.status(429).json({ error: "Too many uploads" });

  try {
    const buf = await readBody(req);
    if (buf.length > MAX_BYTES) return res.status(413).json({ error: "Too large" });

    // Must really be a JPEG (starts FF D8 FF), not just labelled as one.
    if (buf.length < 4 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) {
      return res.status(400).json({ error: "Not a JPEG" });
    }

    await put("pending/pic.jpg", buf, {
      access: "public",
      contentType: "image/jpeg",
      addRandomSuffix: true,
    });
    return res.status(200).json({ ok: true });
  } catch (e) {
    if (e && e.code === 413) return res.status(413).json({ error: "Too large" });
    return res.status(500).json({ error: "Upload failed" });
  }
};
