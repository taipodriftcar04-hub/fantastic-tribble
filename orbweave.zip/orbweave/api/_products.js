// Shared helper (underscore = not a public URL). Each product is stored as a small
// JSON file in "products/" next to its picture. Newest first.

const { list } = require("@vercel/blob");

async function listProducts(limit) {
  const { blobs } = await list({ prefix: "products/", limit: 500 });
  const metas = blobs
    .filter((b) => b.pathname.endsWith(".json"))
    .sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt))
    .slice(0, limit || 60);

  const items = await Promise.all(
    metas.map(async (b) => {
      try {
        const r = await fetch(b.url);
        if (!r.ok) return null;
        const d = await r.json();
        return { id: b.url, name: d.name, desc: d.desc, price: d.price, link: d.link, image: d.image, postedAt: d.postedAt || b.uploadedAt };
      } catch (e) {
        return null;
      }
    })
  );
  return items.filter(Boolean);
}

module.exports = { listProducts };
