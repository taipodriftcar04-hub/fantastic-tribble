// GET /api/member-image?u=<storage url>
// Serves a members-only picture only to signed-in members, so the picture
// never needs to be linked directly from the page.

const { readSession, isMemberBlobUrl } = require("./_auth");

module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).end();
  }
  if (!readSession(req)) return res.status(401).end();

  const u = String(req.query.u || "");
  if (!isMemberBlobUrl(u)) return res.status(400).end();

  try {
    const r = await fetch(u);
    if (!r.ok) return res.status(404).end();
    const buf = Buffer.from(await r.arrayBuffer());
    res.setHeader("Content-Type", "image/jpeg");
    res.setHeader("Cache-Control", "private, max-age=3600");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Robots-Tag", "noindex");
    return res.status(200).send(buf);
  } catch (e) {
    return res.status(502).end();
  }
};
