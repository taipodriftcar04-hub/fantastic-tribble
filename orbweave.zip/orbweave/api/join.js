// POST /api/join  {code}     -> checks the invite code and signs the member in
// POST /api/join  {logout:true} -> signs out

const { checkCode, sessionCookie, clearCookie, jsonBody, limited, clientIp } = require("./_auth");

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }
  const body = jsonBody(req);

  if (body.logout) {
    res.setHeader("Set-Cookie", clearCookie());
    return res.status(200).json({ ok: true });
  }

  // Slow down guessing: 10 tries per 10 minutes per visitor.
  if (limited("join:" + clientIp(req), 10, 10 * 60 * 1000)) {
    return res.status(429).json({ error: "Too many tries. Wait a few minutes." });
  }

  try {
    const c = checkCode(body.code);
    if (!c) return res.status(401).json({ error: "That code is not valid or has expired." });
    res.setHeader("Set-Cookie", sessionCookie(c.id));
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(500).json({ error: "Sign-in is not set up yet." });
  }
};
