// Your private control page. Open:  /api/admin?key=YOUR_ADMIN_KEY
//
// What you can do here:
//   1. Create invite codes for new members
//   2. Approve or delete public-wall pictures waiting for review
//   3. Delete member pictures
//
// Env vars: ADMIN_KEY (16+ chars), SESSION_SECRET (32+ chars), BLOB_READ_WRITE_TOKEN (added by Vercel Blob)

const { list, copy, del, put } = require("@vercel/blob");
const crypto = require("crypto");
const { newCode, isMemberBlobUrl, jsonBody } = require("./_auth");
const { listProducts } = require("./_products");

function esc(s) {
  return String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function cleanText(s, max) {
  return String(s == null ? "" : s).replace(/[\u0000-\u001f]/g, " ").trim().slice(0, max);
}

function authorized(req) {
  const given = String((req.query && req.query.key) || "");
  const expected = String(process.env.ADMIN_KEY || "");
  if (!expected || expected.length < 16) return false;
  const a = Buffer.from(given);
  const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function isBlobUrlUnder(u, folder) {
  try {
    const url = new URL(u);
    return url.protocol === "https:" && url.hostname.endsWith(".blob.vercel-storage.com") && url.pathname.startsWith("/" + folder + "/");
  } catch (e) {
    return false;
  }
}

module.exports = async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  res.setHeader("X-Robots-Tag", "noindex");
  if (!authorized(req)) return res.status(401).send("Unauthorized");

  if (req.method === "POST") {
    const { action, url, days } = jsonBody(req);
    try {
      if (action === "newcode") {
        const d = Number(days);
        if (![7, 30, 90].includes(d)) return res.status(400).json({ error: "Bad length" });
        return res.status(200).json({ code: newCode(d), days: d });
      }
      if (action === "approve" && isBlobUrlUnder(url, "pending")) {
        await copy(url, "approved/pic.jpg", { access: "public", addRandomSuffix: true });
        await del(url);
        return res.status(200).json({ ok: true });
      }
      if (action === "delete" && isBlobUrlUnder(url, "pending")) {
        await del(url);
        return res.status(200).json({ ok: true });
      }
      if (action === "deletemember" && isMemberBlobUrl(url)) {
        await del(url);
        return res.status(200).json({ ok: true });
      }
      if (action === "addproduct") {
        const b = jsonBody(req);
        const name = cleanText(b.name, 80);
        const desc = cleanText(b.desc, 400);
        const price = cleanText(b.price, 30);
        let link = cleanText(b.link, 300);
        if (!name) return res.status(400).json({ error: "Add a product name." });
        if (link && !/^https?:\/\/[^\s]+$/i.test(link)) return res.status(400).json({ error: "The buy link must start with http:// or https://" });
        const raw = String(b.image || "").replace(/^data:image\/jpeg;base64,/, "");
        const buf = Buffer.from(raw, "base64");
        if (buf.length < 4 || buf.length > 2 * 1024 * 1024 || buf[0] !== 0xff || buf[1] !== 0xd8 || buf[2] !== 0xff) {
          return res.status(400).json({ error: "Add a picture (JPEG, up to 2 MB)." });
        }
        const img = await put("products/img.jpg", buf, { access: "public", contentType: "image/jpeg", addRandomSuffix: true });
        const meta = { name, desc, price, link, image: img.url, postedAt: new Date().toISOString() };
        await put("products/p.json", JSON.stringify(meta), { access: "public", contentType: "application/json", addRandomSuffix: true });
        return res.status(200).json({ ok: true });
      }
      if (action === "deleteproduct" && isBlobUrlUnder(url, "products") && /\.json$/.test(new URL(url).pathname)) {
        try {
          const r = await fetch(url);
          if (r.ok) {
            const d = await r.json();
            if (isBlobUrlUnder(d.image, "products")) await del(d.image);
          }
        } catch (e) { /* still remove the listing below */ }
        await del(url);
        return res.status(200).json({ ok: true });
      }
      return res.status(400).json({ error: "Bad request" });
    } catch (e) {
      return res.status(500).json({ error: "Failed" });
    }
  }

  if (req.method !== "GET") return res.status(405).send("Method not allowed");

  const pending = (await list({ prefix: "pending/", limit: 200 })).blobs;
  pending.sort((a, b) => new Date(a.uploadedAt) - new Date(b.uploadedAt));
  const members = (await list({ prefix: "members/", limit: 200 })).blobs;
  members.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
  const key = encodeURIComponent(req.query.key);
  let products = [];
  try { products = await listProducts(60); } catch (e) { products = []; }

  const productCard = (p) => `<div class="c" data-url="${esc(p.id)}" data-kind="product">
      <img src="${esc(p.image)}" alt="${esc(p.name)}" loading="lazy">
      <div><strong>${esc(p.name)}</strong>${p.price ? " &middot; " + esc(p.price) : ""}<br><small>${esc(String(p.postedAt).slice(0, 10))}</small></div>
      <div><button class="no">Delete</button></div>
    </div>`;

  const card = (b, kind) => `<div class="c" data-url="${b.url}" data-kind="${kind}">
      <img src="${b.url}" alt="Picture to review" loading="lazy">
      <div>${kind === "pending" ? '<button class="ok">Approve</button>' : ""}<button class="no">Delete</button></div>
    </div>`;

  res.setHeader("Content-Type", "text/html; charset=utf-8");
  return res.status(200).send(`<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>Orbweave admin</title>
<style>
  body{font-family:system-ui,sans-serif;margin:24px;background:#f3f4f8;color:#181b3a;max-width:1100px}
  h2{margin-top:40px}
  .g{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:16px}
  .c{background:#fff;border-radius:12px;padding:10px;border:1px solid #ccd}
  img{width:100%;border-radius:8px;display:block}
  button,select{font:inherit;padding:9px 14px;margin:10px 8px 0 0;border-radius:8px;border:0;cursor:pointer}
  button{color:#fff;background:#3a3fe0}
  .ok{background:#2a7a3b}.no{background:#b3361f}
  select{background:#fff;border:1px solid #ccd;color:#181b3a}
  input[type=text],textarea{font:inherit;width:100%;padding:9px 10px;border-radius:8px;border:1px solid #ccd;margin-top:4px}
  label{font-weight:600;display:block}
  .box{background:#fff;border:1px solid #ccd;border-radius:12px;padding:16px}
  #codes div{font-family:ui-monospace,monospace;font-size:1.1rem;margin:8px 0;user-select:all}
</style></head><body>
<h1>Orbweave admin</h1>

<h2>Post a product</h2>
<div class="box">
  <p>Fill this in and press Post. It shows at the top of the home page straight away (allow up to a minute). Come back each day to add the next one.</p>
  <form id="pf" style="display:grid;gap:10px;max-width:520px">
    <label>Picture <input type="file" id="pfImg" accept="image/jpeg,image/png,image/webp"></label>
    <img id="pfPrev" alt="Preview" style="max-width:200px;display:none">
    <label>Name <input type="text" id="pfName" maxlength="80" placeholder="Product name"></label>
    <label>Price <input type="text" id="pfPrice" maxlength="30" placeholder="$24.99"></label>
    <label>Short description <textarea id="pfDesc" maxlength="400" rows="3" placeholder="One or two sentences"></textarea></label>
    <label>Buy link (optional) <input type="text" id="pfLink" maxlength="300" placeholder="https://your-store.com/product"></label>
    <div><button type="submit" id="pfBtn">Post product</button></div>
    <div id="pfMsg" role="status"></div>
  </form>
</div>

<h2>Posted products (${products.length})</h2>
<div class="g">${products.map(productCard).join("") || "<p>No products yet.</p>"}</div>

<h2>Invite codes</h2>
<div class="box">
  <p>Make a code, then email it to the person you are inviting. Each code works for many sign-ins until it expires, so share it with one person only. To block a code early, add its first 6 letters to the REVOKED_CODES setting in Vercel and redeploy.</p>
  <label>Valid for <select id="days"><option value="7">7 days</option><option value="30" selected>30 days</option><option value="90">90 days</option></select></label>
  <button id="mk">Create code</button>
  <div id="codes" aria-live="polite"></div>
</div>

<h2>Wall pictures waiting for review (${pending.length})</h2>
<p>Look at each picture at full size before approving. Delete anything unsafe, illegal, or showing people who may not have agreed.</p>
<div class="g">${pending.map((b) => card(b, "pending")).join("") || "<p>Nothing waiting for review.</p>"}</div>

<h2>Member pictures (${members.length})</h2>
<p>Members post these without review, so check them from time to time and delete anything that breaks your rules.</p>
<div class="g">${members.map((b) => card(b, "member")).join("") || "<p>No member pictures yet.</p>"}</div>

<script>
var KEY="${key}";
function post(body){
  return fetch("/api/admin?key="+KEY,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(body)})
    .then(function(r){ return r.json().catch(function(){return {};}).then(function(d){ if(!r.ok){ var e=new Error(d.error||"Failed"); throw e; } return d; }); });
}
var pfBlob=null;
document.getElementById("pfImg").onchange=function(){
  var f=this.files[0]; pfBlob=null; document.getElementById("pfPrev").style.display="none"; if(!f) return;
  var url=URL.createObjectURL(f), img=new Image();
  img.onload=function(){
    var s=Math.min(1,1400/Math.max(img.naturalWidth,img.naturalHeight));
    var c=document.createElement("canvas"); c.width=Math.round(img.naturalWidth*s); c.height=Math.round(img.naturalHeight*s);
    var x=c.getContext("2d"); x.fillStyle="#fff"; x.fillRect(0,0,c.width,c.height); x.drawImage(img,0,0,c.width,c.height);
    c.toBlob(function(b){
      URL.revokeObjectURL(url);
      var rd=new FileReader(); rd.onload=function(){ pfBlob=rd.result; var p=document.getElementById("pfPrev"); p.src=rd.result; p.style.display="block"; }; rd.readAsDataURL(b);
    },"image/jpeg",0.85);
  };
  img.onerror=function(){ alert("Could not read that picture."); };
  img.src=url;
};
document.getElementById("pf").onsubmit=function(ev){
  ev.preventDefault();
  var msg=document.getElementById("pfMsg"); msg.textContent="";
  if(!pfBlob){ msg.textContent="Choose a picture first."; return; }
  var btn=document.getElementById("pfBtn"); btn.disabled=true;
  post({action:"addproduct",image:pfBlob,name:document.getElementById("pfName").value,price:document.getElementById("pfPrice").value,desc:document.getElementById("pfDesc").value,link:document.getElementById("pfLink").value})
    .then(function(){ location.reload(); })
    .catch(function(e){ msg.textContent=e.message||"Could not post. Try again."; btn.disabled=false; });
};
document.getElementById("mk").onclick=function(){
  var d=Number(document.getElementById("days").value);
  post({action:"newcode",days:d}).then(function(r){
    var el=document.createElement("div"); el.textContent=r.code+"   (valid "+r.days+" days)";
    document.getElementById("codes").prepend(el);
  }).catch(function(){ alert("Could not create a code. Check that SESSION_SECRET is set."); });
};
document.querySelectorAll(".c").forEach(function(card){
  var kind=card.dataset.kind;
  function act(action){
    post({action:action,url:card.dataset.url}).then(function(){ card.remove(); })
      .catch(function(){ alert("That did not work. Reload and try again."); });
  }
  var ok=card.querySelector(".ok"); if(ok) ok.onclick=function(){act("approve")};
  card.querySelector(".no").onclick=function(){act(kind==="pending"?"delete":kind==="product"?"deleteproduct":"deletemember")};
});
</script></body></html>`);
};
