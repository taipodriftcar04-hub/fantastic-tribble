// GET /api/products -> { products: [ {name, desc, price, link, image, postedAt}, ... ] } newest first

const { listProducts } = require("./_products");

module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "Method not allowed" });
  }
  try {
    const items = await listProducts(60);
    res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");
    return res.status(200).json({
      products: items.map((p) => ({ name: p.name, desc: p.desc, price: p.price, link: p.link, image: p.image, postedAt: p.postedAt })),
    });
  } catch (e) {
    return res.status(200).json({ products: [] });
  }
};
