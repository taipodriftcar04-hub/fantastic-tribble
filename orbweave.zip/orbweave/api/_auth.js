// Shared helpers (the leading underscore stops Vercel from exposing this file as a URL).
//
// Invite codes are signed, so they need no database:  abc234-0kq2-1a2b3c4d5e6f
//   id (6 chars) - expiry day (base36) - signature
// Member sessions are signed cookies that last 30 days.
//
// Required env var: SESSION_SECRET (random string, 32+ characters)
// Optional env var: REVOKED_CODES (comma-separated code ids to block, e.g. "abc234,xyz789")

const crypto = require("crypto");

const DAY = 86400000;
const ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789";
const COOKIE = "ow_member";

function secret() {
  const s = process.env.SESSION_SECRET || "";
  if (s.length < 32) throw new Error("SESSION_SECRET is missing or too short");
  return s;
}
function hmac(data) {
  return crypto.createHmac("sha256", secret()).update(data).digest("hex");
}
function safeEq(a, b) {
  const A = Buffer.from(String(a));
  const B = Buffer.from(String(b));
  return A.length === B.length && crypto.timingSafeEqual(A, B);
}
function revoked() {
  return (process.env.REVOKED_CODES || "").toLowerCase().split(",").map((s) => s.trim()).filter(Boolean);
}

function newCode(days) {
  let id = "";
  const bytes = crypto.randomBytes(6);
  for (let i = 0; i < 6; i++) id += ALPHABET[bytes[i] % ALPHABET.length];
  const exp = Math.floor(Date.now() / DAY) + Math.max(1, Math.min(365, days | 0));
  const expStr = exp.toString(36).padStart(4, "0");
  const sig = hmac("code:" + id + expStr).slice(0, 12);
  return `${id}-${expStr}-${sig}`;
}

function checkCode(raw) {
  const m = /^([a-z2-9]{6})-([0-9a-z]{4})-([0-9a-f]{12})$/.exec(String(raw || "").trim().toLowerCase());
  if (!m) return null;
  const [, id, expStr, sig] = m;
  if (!safeEq(hmac("code:" + id + expStr).slice(0, 12), sig)) return null;
  if (parseInt(expStr, 36) < Math.floor(Date.now() / DAY)) return null;
  if (revoked().includes(id)) return null;
  return { id };
}

function sessionCookie(id) {
  const payload = Buffer.from(JSON.stringify({ id, exp: Date.now() + 30 * DAY })).toString("base64url");
  const token = payload + "." + hmac("sess:" + payload);
  return `${COOKIE}=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${30 * 86400}`;
}
function clearCookie() {
  return `${COOKIE}=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0`;
}

function readSession(req) {
  try {
    const header = req.headers.cookie || "";
    const pair = header.split(";").map((s) => s.trim()).find((s) => s.startsWith(COOKIE + "="));
    if (!pair) return null;
    const token = pair.slice(COOKIE.length + 1);
    const [payload, sig] = token.split(".");
    if (!payload || !sig || !safeEq(hmac("sess:" + payload), sig)) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    if (!data.exp || data.exp < Date.now()) return null;
    if (revoked().includes(String(data.id))) return null;
    return { id: data.id };
  } catch (e) {
    return null;
  }
}

async function readBody(req, max) {
  if (Buffer.isBuffer(req.body)) return req.body;
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > max) throw Object.assign(new Error("too large"), { code: 413 });
    chunks.push(chunk);
  }
  return Buffer.concat(chunks);
}

function jsonBody(req) {
  if (typeof req.body === "string") {
    try { return JSON.parse(req.body); } catch (e) { return {}; }
  }
  return req.body && typeof req.body === "object" && !Buffer.isBuffer(req.body) ? req.body : {};
}

function isMemberBlobUrl(u) {
  try {
    const url = new URL(u);
    return url.protocol === "https:" && url.hostname.endsWith(".blob.vercel-storage.com") && url.pathname.startsWith("/members/");
  } catch (e) {
    return false;
  }
}

const hits = new Map();
function limited(key, max, windowMs) {
  const now = Date.now();
  const recent = (hits.get(key) || []).filter((t) => now - t < windowMs);
  recent.push(now);
  hits.set(key, recent);
  return recent.length > max;
}
function clientIp(req) {
  return (req.headers["x-forwarded-for"] || "").split(",")[0].trim() || "unknown";
}

module.exports = { newCode, checkCode, sessionCookie, clearCookie, readSession, readBody, jsonBody, isMemberBlobUrl, limited, clientIp, safeEq };
