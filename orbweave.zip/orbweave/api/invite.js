// Vercel serverless function: receives an invite request and emails it to you.
// Nothing is stored on a server or database; the request lives only in your inbox.
//
// Required environment variables (Vercel > Project > Settings > Environment Variables):
//   RESEND_API_KEY   your key from resend.com
//   INVITE_TO_EMAIL  the inbox that should receive requests
// Optional:
//   INVITE_FROM_EMAIL  defaults to Resend's test sender (only delivers to your own Resend account email)

module.exports = async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const body = typeof req.body === "string" ? safeParse(req.body) : req.body || {};
  const email = String(body.email || "").trim();

  // Spam trap: real people never fill this hidden field. Pretend success.
  if (body.website) return res.status(200).json({ ok: true });

  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) {
    return res.status(400).json({ error: "Enter a valid email address." });
  }

  const key = process.env.RESEND_API_KEY;
  const to = process.env.INVITE_TO_EMAIL;
  if (!key || !to) {
    return res.status(500).json({ error: "Server is not configured." });
  }

  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.INVITE_FROM_EMAIL || "Orbweave <onboarding@resend.dev>",
        to: [to],
        reply_to: email,
        subject: "New Orbweave invite request",
        text: `Invite request from: ${email}\n\nReply to this email to send their invite, then delete this message.`,
      }),
    });
    if (!r.ok) return res.status(502).json({ error: "Could not send request." });
    return res.status(200).json({ ok: true });
  } catch (e) {
    return res.status(502).json({ error: "Could not send request." });
  }
};

function safeParse(s) {
  try { return JSON.parse(s); } catch (e) { return {}; }
}
