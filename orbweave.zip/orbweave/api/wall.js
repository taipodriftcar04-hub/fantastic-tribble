// GET /api/wall  -> { images: [url, ...] }  newest first, approved pictures only.

const { list } = require("@vercel/blob");

module.exports = async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "Method not allowed" });
  }
  try {
    const { blobs } = await list({ prefix: "approved/", limit: 100 });
    blobs.sort((a, b) => new Date(b.uploadedAt) - new Date(a.uploadedAt));
    res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");
    return res.status(200).json({ images: blobs.map((b) => b.url) });
  } catch (e) {
    return res.status(200).json({ images: [] });
  }
};
